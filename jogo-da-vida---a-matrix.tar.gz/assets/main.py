# main.py
# Versão Final WEB: Otimizada + Áudio Seguro Anti-Crash (Toque/Clique 100% Funcional)

import pygame
import sys
import os
import random 
import asyncio 
from utils import (
    desenhar_texto, desenhar_botao, desenhar_janela_central, MatrixRain,
    BRANCO, PRETO, VERDE, VERMELHO, AZUL, AMARELO, CINZA,
    VERDE_MATRIX, PRETO_MATRIX, desenhar_texto_formatado
)
import jogo

pygame.init()
pygame.mixer.init() 

# ----------------------------
# Configurações da tela (Fixa e Otimizada para Web)
# ----------------------------
LARGURA, ALTURA = 1280, 720
TELA = pygame.display.set_mode((LARGURA, ALTURA)) 
pygame.display.set_caption("Jogo da Vida - A Matrix")

# =====================================================================================
# FUNÇÕES DE ÁUDIO SEGURO (Impede o navegador de travar)
# =====================================================================================
def tocar_som(som):
    if som:
        try: som.play()
        except: pass

def tocar_musica():
    try:
        if not pygame.mixer.music.get_busy():
            pygame.mixer.music.play(-1)
    except: pass

def parar_musica():
    try: pygame.mixer.music.stop()
    except: pass

def pausar_musica():
    try: pygame.mixer.music.pause()
    except: pass

def despausar_musica():
    try: pygame.mixer.music.unpause()
    except: pass

# =====================================================================================
# TELA DE LOADING
# =====================================================================================

try:
    fonte_loading_titulo = pygame.font.SysFont("arialblack", 32)
    fonte_loading_rain = pygame.font.SysFont("consolas", 18)
except:
    fonte_loading_titulo = pygame.font.SysFont(None, 40) 
    fonte_loading_rain = pygame.font.SysFont(None, 20)  

class LoadingRain:
    def __init__(self, largura, altura, fonte):
        self.largura = largura
        self.altura = altura
        self.fonte = fonte
        self.tam_fonte_w = fonte.size("0")[0]
        self.tam_fonte_h = fonte.get_height()
        self.colunas = max(1, largura // self.tam_fonte_w)
        self.y_pos = [random.randint(-200, 0) for _ in range(self.colunas)]
        self.vel = [random.randint(2, 6) for _ in range(self.colunas)]
        self.caracteres = ['0', '1']

    def desenhar(self, tela):
        cor_verde = (0, 255, 70)
        for i in range(self.colunas):
            char = random.choice(self.caracteres)
            try:
                surf = self.fonte.render(char, True, cor_verde)
            except:
                surf = pygame.font.SysFont(None, 20).render(char, True, cor_verde)
            x = i * self.tam_fonte_w
            y = self.y_pos[i]
            if 0 <= y <= self.altura:
                tela.blit(surf, (x, y))
            self.y_pos[i] = self.y_pos[i] + self.vel[i]
            if self.y_pos[i] > self.altura:
                self.y_pos[i] = random.randint(-100, 0)

def desenhar_tela_loading(progresso, total, rain_effect):
    TELA.fill(PRETO_MATRIX)
    rain_effect.desenhar(TELA)
    texto_surf = fonte_loading_titulo.render("ENTRANDO NA MATRIX, PREPARE-SE", True, BRANCO)
    texto_rect = texto_surf.get_rect(center=(LARGURA // 2, ALTURA // 2))
    TELA.blit(texto_surf, texto_rect)

    bar_w = LARGURA * 0.6
    bar_h = 25
    bar_x = LARGURA // 2 - bar_w // 2
    bar_y = ALTURA * 0.70
    percent = progresso / total
    current_w = max(0, bar_w * percent)
    
    pygame.draw.rect(TELA, (50, 50, 50), (bar_x, bar_y, bar_w, bar_h), border_radius=5)
    pygame.draw.rect(TELA, VERDE_MATRIX, (bar_x, bar_y, current_w, bar_h), border_radius=5)
    pygame.draw.rect(TELA, BRANCO, (bar_x, bar_y, bar_w, bar_h), 2, border_radius=5)
    pygame.display.flip()

# Variáveis de assets pré-declaradas
fonte = None
fonte_titulo = None
fonte_subtitulo = None
fonte_botao = None
fonte_mono = None
fonte_prologo = None
fonte_peao_nome = None 
VOLUME_GERAL = 1.0  
VOLUME_MUSICA = 0.5 
VOLUME_EFEITOS = 0.5 
click_sound = None
move_sound = None
dice_roll_sound = None
falha_sound = None
cutscene_sound = None
personagem_sprites = {}
selecao_sprites = {}
peao_sprites = {}
splash_bg = None      
cutscene_bg = None    
regras_bg_sprite = None 
personagens_nomes_cartas = ["neo", "trinity", "morpheus", "oraculo", "operador", "smith", "merovingio", "gemeos", "arquiteto"]
DADO_TAMANHO = (150, 150)
dice_roll_sprites = []
dice_result_sprites = {}
rain_effect = None

def carregar_assets():
    global fonte, fonte_titulo, fonte_subtitulo, fonte_botao, fonte_mono, fonte_prologo, fonte_peao_nome
    global click_sound, move_sound, dice_roll_sound, falha_sound, cutscene_sound
    global personagem_sprites, selecao_sprites, peao_sprites, splash_bg, cutscene_bg, regras_bg_sprite
    global dice_roll_sprites, dice_result_sprites

    total_assets = 7 + 7 + len(personagens_nomes_cartas) + (4*2) + 1 + (6*2) + 2 
    progresso = 0

    fonte = pygame.font.SysFont("arial", 24)
    progresso += 1; yield progresso, total_assets
    fonte_titulo = pygame.font.SysFont("arialblack", 55)
    progresso += 1; yield progresso, total_assets
    fonte_subtitulo = pygame.font.SysFont("arialblack", 32)
    progresso += 1; yield progresso, total_assets
    fonte_botao = pygame.font.SysFont("arialblack", 24)
    progresso += 1; yield progresso, total_assets
    fonte_mono = pygame.font.SysFont("consolas", 18)
    progresso += 1; yield progresso, total_assets
    fonte_prologo = pygame.font.SysFont("arialblack", 26)
    progresso += 1; yield progresso, total_assets
    fonte_peao_nome = pygame.font.SysFont("arial", 16, bold=True) 
    progresso += 1; yield progresso, total_assets

    try: pygame.mixer.music.load(os.path.join("assets", "musica_menu.mp3"))
    except: pass
    progresso += 1; yield progresso, total_assets

    try: click_sound = pygame.mixer.Sound(os.path.join("assets", "click.wav"))
    except: click_sound = None
    progresso += 1; yield progresso, total_assets

    try: move_sound = pygame.mixer.Sound(os.path.join("assets", "move.wav"))
    except: move_sound = None
    progresso += 1; yield progresso, total_assets

    try: dice_roll_sound = pygame.mixer.Sound(os.path.join("assets", "dados.mp3"))
    except: dice_roll_sound = None
    progresso += 1; yield progresso, total_assets

    try: falha_sound = pygame.mixer.Sound(os.path.join("assets", "falha.mp3"))
    except: falha_sound = None
    progresso += 1; yield progresso, total_assets

    try: cutscene_sound = pygame.mixer.Sound(os.path.join("assets", "cutcine.mp3"))
    except: cutscene_sound = None
    progresso += 1; yield progresso, total_assets
    
    for nome in personagens_nomes_cartas:
        try:
            imagem = pygame.image.load(os.path.join("assets", "images", f"{nome}.png")).convert_alpha()
            personagem_sprites[nome] = pygame.transform.scale(imagem, (90, 90))
        except: pass
        progresso += 1; yield progresso, total_assets

    for i in range(1, 5):
        try:
            img_selecao = pygame.image.load(os.path.join("assets", "images", f"programador_{i}.png")).convert_alpha()
            selecao_sprites[i] = pygame.transform.scale(img_selecao, (130, 130))
            progresso += 1; yield progresso, total_assets
            
            peao_sprites[i] = pygame.image.load(os.path.join("assets", "personagens", f"programador_{i}.png")).convert_alpha()
            progresso += 1; yield progresso, total_assets
        except: pass

    try:
        splash_bg = pygame.image.load(os.path.join("assets", "frames_splash", "0187.png")).convert_alpha()
        splash_bg = pygame.transform.scale(splash_bg, (LARGURA, ALTURA))
    except: splash_bg = None
    progresso += 1; yield progresso, total_assets

    try:
        cutscene_bg = pygame.image.load(os.path.join("assets", "frames_cutscene", "0171.png")).convert_alpha()
        cutscene_bg = pygame.transform.scale(cutscene_bg, (LARGURA, ALTURA))
    except: cutscene_bg = None
    progresso += 1; yield progresso, total_assets

    try: regras_bg_sprite = pygame.image.load(os.path.join("assets", "images", "regras_bg.png")).convert_alpha()
    except: regras_bg_sprite = None
    progresso += 1; yield progresso, total_assets

    for i in range(1, 7): 
        try:
            img = pygame.image.load(os.path.join("assets", "dados", f"ROLL_{i:02d}.png")).convert_alpha()
            dice_roll_sprites.append(pygame.transform.scale(img, DADO_TAMANHO))
        except: pass
        progresso += 1; yield progresso, total_assets

    for i in range(1, 7): 
        try:
            img = pygame.image.load(os.path.join("assets", "dados", f"DADO_{i}.png")).convert_alpha()
            dice_result_sprites[i] = pygame.transform.scale(img, DADO_TAMANHO)
        except: pass
        progresso += 1; yield progresso, total_assets

# Estados do Jogo
SPLASH_SCREEN = "splash_screen"
MENU = "menu"
OPCOES = "opcoes"
QTD_JOGADORES = "qtd_jogadores"
NOME = "nome"
SELECAO_PERSONAGEM = "selecao_personagem"
PROLOGO = "prologo"
CUTSCENE = "cutscene" 
REGRAS = "regras"
JOGO = "jogo"
PILULA_FINAL = "pilula_final"
PILULA_FALHA = "pilula_falha"
FIM = "fim"
PAUSA = "pausa" 
MOSTRAR_BUFF = "mostrar_buff" 
estado = SPLASH_SCREEN 

# Variáveis de controle globais
nomes = ["Programador 1", "Programador 2", "Programador 3", "Programador 4"] 
foco_jogador = 0
cursor_on = True
cursor_timer = 0
num_jogadores = 2
jogador_selecionando = 0
personagens_escolhidos = []
estado_anterior_opcoes = None 
jogador_com_buff = None 
pilula_final_peao = None 

prologo_scroll_y = ALTURA
PROLOGO_SCROLL_SPEED = 0.85 
PROLOGO_LINES = [] 

epilogo_scroll_y = ALTURA
EPILOGO_SCROLL_SPEED = 0.85 
EPILOGO_LINES = []
fim_scroll_acabou = False 

animacao_em_andamento = False
peao_animando = None
passos_restantes = 0
passos_direcao = 1 
o_que_fazer_depois_anim = None 
animacao_replay = False 
timer_animacao = 0
TEMPO_PASSO = 100 
frame_atual = 0 
timer_frame = 0 
TEMPO_FRAME = 200

timer_cutscene_estatica = 0
DURACAO_CUTSCENE_WEB = 4000 

estado_anim_dado = "nenhum" 
timer_anim_dado = 0
dado_frame_atual = 0 
dado_frame_timer = 0
dado_resultado_sorteado = 0
DURACAO_ANIM_DADO = 1000   
DURACAO_MOSTRAR_DADO = 1000 
TEMPO_FRAME_DADO = 50      

rects_botoes_menu = {}
rects_botoes_opcoes = {}
rects_botoes_qtd = {}
rects_botoes_nome = {}
rects_botoes_selecao = {}
rects_botoes_pilula = {}
rects_botoes_pausa = {} 
rects_botoes_prologo = {} 
rects_botoes_regras = {}
rects_botoes_fim = {} 
rects_botoes_jogo = {} 

# =====================================================================================
# FUNÇÕES DE DESENHO
# =====================================================================================

def desenhar_splash_screen():
    TELA.fill(PRETO_MATRIX)
    if splash_bg: 
        TELA.blit(splash_bg, (0, 0))
    else: 
        if rain_effect: rain_effect.update_and_draw(TELA)
    desenhar_texto(TELA, "JOGO DA VIDA - A MATRIX", LARGURA//2, ALTURA//2 - 50, VERDE_MATRIX, True, fonte_titulo)
    desenhar_texto(TELA, "CLIQUE NA TELA PARA INICIAR A CONEXÃO", LARGURA//2, ALTURA - 100, BRANCO, True, fonte_botao)

def desenhar_menu():
    global rects_botoes_menu
    rects_botoes_menu = {} 
    TELA.fill(PRETO_MATRIX)
    if rain_effect: rain_effect.update_and_draw(TELA)
    desenhar_texto(TELA, "Jogo da Vida - A Matrix", LARGURA//2, ALTURA * 0.15, VERDE_MATRIX, True, fonte_titulo)
    btn_w, btn_h = 280, 60
    btn_x = LARGURA // 2 - btn_w // 2
    y_start = ALTURA * 0.4
    desenhar_botao(TELA, "Iniciar Jogo", btn_x, y_start, btn_w, btn_h, (10,40,10), (20,80,20), fonte_botao)
    rects_botoes_menu["iniciar"] = pygame.Rect(btn_x, y_start, btn_w, btn_h)
    desenhar_botao(TELA, "Opções", btn_x, y_start + btn_h + 20, btn_w, btn_h, (10,10,40), (20,20,80), fonte_botao)
    rects_botoes_menu["opcoes"] = pygame.Rect(btn_x, y_start + btn_h + 20, btn_w, btn_h)
    desenhar_botao(TELA, "Sair", btn_x, y_start + 2 * (btn_h + 20), btn_w, btn_h, (40,10,10), (80,20,20), fonte_botao)
    rects_botoes_menu["sair"] = pygame.Rect(btn_x, y_start + 2 * (btn_h + 20), btn_w, btn_h)

def desenhar_opcoes():
    global rects_botoes_opcoes
    rects_botoes_opcoes = {}
    TELA.fill(PRETO_MATRIX)
    if rain_effect: rain_effect.update_and_draw(TELA)
    desenhar_texto(TELA, "Opções", LARGURA//2, ALTURA * 0.1, VERDE_MATRIX, True, fonte_titulo)
    btn_vol_size = 45 
    y_start = ALTURA * 0.25
    desenhar_texto(TELA, "Volume Geral", LARGURA//2, y_start, BRANCO, True, fonte_botao)
    desenhar_botao(TELA, "-", LARGURA//2 - 100, y_start + 30, btn_vol_size, btn_vol_size, (40,40,40), (80,80,80), fonte_botao)
    rects_botoes_opcoes["geral-"] = pygame.Rect(LARGURA//2 - 100, y_start + 30, btn_vol_size, btn_vol_size)
    desenhar_texto(TELA, f"{int(VOLUME_GERAL*100)}%", LARGURA//2, y_start + 50, BRANCO, True, fonte_botao)
    desenhar_botao(TELA, "+", LARGURA//2 + 60, y_start + 30, btn_vol_size, btn_vol_size, (40,40,40), (80,80,80), fonte_botao)
    rects_botoes_opcoes["geral+"] = pygame.Rect(LARGURA//2 + 60, y_start + 30, btn_vol_size, btn_vol_size)
    y_start += 110 
    desenhar_texto(TELA, "Música", LARGURA//2, y_start, BRANCO, True, fonte_botao)
    desenhar_botao(TELA, "-", LARGURA//2 - 100, y_start + 30, btn_vol_size, btn_vol_size, (40,40,40), (80,80,80), fonte_botao)
    rects_botoes_opcoes["musica-"] = pygame.Rect(LARGURA//2 - 100, y_start + 30, btn_vol_size, btn_vol_size)
    desenhar_texto(TELA, f"{int(VOLUME_MUSICA*100)}%", LARGURA//2, y_start + 50, BRANCO, True, fonte_botao)
    desenhar_botao(TELA, "+", LARGURA//2 + 60, y_start + 30, btn_vol_size, btn_vol_size, (40,40,40), (80,80,80), fonte_botao)
    rects_botoes_opcoes["musica+"] = pygame.Rect(LARGURA//2 + 60, y_start + 30, btn_vol_size, btn_vol_size)
    y_start += 110 
    desenhar_texto(TELA, "Efeitos Sonoros", LARGURA//2, y_start, BRANCO, True, fonte_botao)
    desenhar_botao(TELA, "-", LARGURA//2 - 100, y_start + 30, btn_vol_size, btn_vol_size, (40,40,40), (80,80,80), fonte_botao)
    rects_botoes_opcoes["efeitos-"] = pygame.Rect(LARGURA//2 - 100, y_start + 30, btn_vol_size, btn_vol_size)
    desenhar_texto(TELA, f"{int(VOLUME_EFEITOS*100)}%", LARGURA//2, y_start + 50, BRANCO, True, fonte_botao)
    desenhar_botao(TELA, "+", LARGURA//2 + 60, y_start + 30, btn_vol_size, btn_vol_size, (40,40,40), (80,80,80), fonte_botao)
    rects_botoes_opcoes["efeitos+"] = pygame.Rect(LARGURA//2 + 60, y_start + 30, btn_vol_size, btn_vol_size)
    btn_voltar_w, btn_voltar_h = 350, 55 
    texto_voltar = "Voltar à Pausa" if estado_anterior_opcoes == PAUSA else "Voltar ao Menu"
    desenhar_botao(TELA, texto_voltar, LARGURA//2 - btn_voltar_w//2, ALTURA - 80, btn_voltar_w, btn_voltar_h, (40,10,10), (80,20,20), fonte_botao)
    rects_botoes_opcoes["voltar"] = pygame.Rect(LARGURA//2 - btn_voltar_w//2, ALTURA - 80, btn_voltar_w, btn_voltar_h)

def desenhar_qtd_jogadores():
    global num_jogadores, nomes, rects_botoes_qtd
    rects_botoes_qtd = {}
    TELA.fill(PRETO_MATRIX)
    if rain_effect: rain_effect.update_and_draw(TELA)
    desenhar_texto(TELA, "Quantidade de Programadores", LARGURA//2, ALTURA * 0.15, VERDE_MATRIX, True, fonte_titulo)
    btn_size = 90
    spacing = 20
    total_width = 3 * btn_size + 2 * spacing
    start_x = LARGURA//2 - total_width // 2
    y_pos = ALTURA * 0.4
    for i in range(2, 5):
        x_pos = start_x + (i - 2) * (btn_size + spacing)
        desenhar_botao(TELA, str(i), x_pos, y_pos, btn_size, btn_size, (10,40,10), (20,80,20), fonte_botao)
        rects_botoes_qtd[i] = pygame.Rect(x_pos, y_pos, btn_size, btn_size)

def desenhar_nome():
    global cursor_on, cursor_timer, foco_jogador, nomes, rects_botoes_nome
    rects_botoes_nome = {}
    TELA.fill(PRETO_MATRIX)
    if rain_effect: rain_effect.update_and_draw(TELA)
    desenhar_texto(TELA, "Identifiquem-se, Programadores", LARGURA//2, ALTURA * 0.12, VERDE_MATRIX, True, fonte_titulo)
    cursor_timer += 1
    if cursor_timer > 25: cursor_on = not cursor_on; cursor_timer = 0
    teclas_legenda = ["A", "G", "J", "L"]
    campo_w, campo_w_h = LARGURA * 0.5, 55 
    campos_y = ALTURA * 0.25
    for i in range(num_jogadores):
        x = LARGURA//2 - campo_w//2
        y = campos_y + i*(campo_w_h + 12)
        pygame.draw.rect(TELA, (5,25,5), (x, y, campo_w, campo_w_h), border_radius=8)
        pygame.draw.rect(TELA, VERDE_MATRIX, (x, y, campo_w, campo_w_h), 2, border_radius=8)
        texto = nomes[i] + ("_" if cursor_on and foco_jogador == i else "")
        desenhar_texto(TELA, f"Prog {i+1} (tecla: {teclas_legenda[i]}): {texto}", x+12, y + campo_w_h//2 - 11, VERDE_MATRIX, False, fonte_mono)
    btn_w, btn_h = 280, 60
    btn_y = campos_y + num_jogadores*(campo_w_h + 12) + 20
    desenhar_botao(TELA, "Confirmar Nomes", LARGURA//2 - btn_w//2, btn_y, btn_w, btn_h, (10,40,10), (20,80,20), fonte_botao)
    rects_botoes_nome["confirmar"] = pygame.Rect(LARGURA//2 - btn_w//2, btn_y, btn_w, btn_h)

def desenhar_selecao_personagem():
    global jogador_selecionando, personagens_escolhidos, rects_botoes_selecao
    rects_botoes_selecao = {}
    TELA.fill(PRETO_MATRIX)
    if rain_effect: rain_effect.update_and_draw(TELA)
    nome_jogador = jogo.peoes[jogador_selecionando]['nome']
    desenhar_texto(TELA, f"{nome_jogador}, escolha seu avatar:", LARGURA//2, ALTURA * 0.15, VERDE_MATRIX, True, fonte_titulo)
    num_chars = len(selecao_sprites)
    sprite_w, sprite_h = 130, 130
    spacing = 25
    total_w = num_chars * sprite_w + (num_chars - 1) * spacing
    start_x = LARGURA//2 - total_w//2
    y_pos = ALTURA//2 - sprite_h//2
    for i in range(1, num_chars + 1):
        x = start_x + (i - 1) * (sprite_w + spacing)
        if i in selecao_sprites:
            sprite = selecao_sprites[i]
            rect = sprite.get_rect(topleft=(x, y_pos))
            rects_botoes_selecao[i] = rect
            mouse_pos = pygame.mouse.get_pos()
            if i in personagens_escolhidos:
                surf = pygame.Surface(rect.size, pygame.SRCALPHA); surf.fill((50, 50, 50, 180)); TELA.blit(sprite, rect); TELA.blit(surf, rect)
                desenhar_texto(TELA, "Escolhido", rect.centerx, rect.bottom + 15, CINZA, True, fonte)
            else:
                if rect.collidepoint(mouse_pos):
                    pygame.draw.rect(TELA, VERDE_MATRIX, (rect.x-4, rect.y-4, rect.w+8, rect.h+8), 2, border_radius=8)
                TELA.blit(sprite, rect)

def desenhar_prologo():
    global rects_botoes_prologo, prologo_scroll_y, PROLOGO_LINES
    TELA.fill(PRETO_MATRIX)
    if rain_effect: rain_effect.update_and_draw(TELA)
    rects_botoes_prologo = {} 
    if not PROLOGO_LINES:
        prologo_scroll_y = ALTURA + 40 
        max_width = LARGURA * 0.85 
        for pagina in jogo.PAGINAS_DA_LORE:
            paragrafos = pagina.split('\n\n') 
            for paragrafo in paragrafos:
                palavras = paragrafo.replace('\n', ' ').split(' ')
                linha_atual = ""
                for palavra in palavras:
                    linha_teste = linha_atual + palavra + " "
                    if fonte_prologo.size(linha_teste)[0] < max_width:
                        linha_atual = linha_teste
                    else:
                        PROLOGO_LINES.append(linha_atual)
                        linha_atual = palavra + " "
                PROLOGO_LINES.append(linha_atual) 
                PROLOGO_LINES.append("") 
    line_height = fonte_prologo.get_linesize()
    for i, line in enumerate(PROLOGO_LINES):
        y_pos = prologo_scroll_y + (i * line_height)
        if y_pos < ALTURA and y_pos > -line_height:
            desenhar_texto(TELA, line, LARGURA // 2, y_pos, AMARELO, True, fonte_prologo)
    btn_w, btn_h = 130, 50
    btn_x, btn_y = LARGURA - btn_w - 20, ALTURA - btn_h - 20
    desenhar_botao(TELA, "Pular", btn_x, btn_y, btn_w, btn_h, (40,10,10), (80,20,20), fonte_botao)
    rects_botoes_prologo["pular"] = pygame.Rect(btn_x, btn_y, btn_w, btn_h)
    posicao_final_texto = prologo_scroll_y + (len(PROLOGO_LINES) * line_height)
    return posicao_final_texto

def desenhar_cutscene():
    TELA.fill(PRETO_MATRIX) 
    if cutscene_bg:
        TELA.blit(cutscene_bg, (0, 0))
    else:
        if rain_effect: rain_effect.update_and_draw(TELA)
    desenhar_texto(TELA, "CONECTANDO LINHA SEGURA COM ZION...", LARGURA//2, ALTURA//2, VERDE_MATRIX, True, fonte_subtitulo)
    desenhar_texto(TELA, "Aguarde um instante ou clique na tela para pular", LARGURA//2, ALTURA - 100, BRANCO, True, fonte)

def desenhar_regras():
    global rects_botoes_regras
    rects_botoes_regras = {}
    if regras_bg_sprite:
        TELA.blit(regras_bg_sprite, (0, 0))
    else:
        TELA.fill(PRETO_MATRIX) 
        if rain_effect: rain_effect.update_and_draw(TELA)
    regras = ("1. Use o BOTÃO DE AÇÃO UNIVERSAL na parte inferior da tela para comandar o jogo.\n\n"
              "2. O seu peão avançará de acordo com o dado. Ao parar, uma transmissão será aberta.\n\n"
              "3. Leia as instruções da tela com atenção. Cartas vermelhas podem causar atrasos.\n\n"
              "4. Chegue até a célula final de Saída e selecione a pílula certa para salvar Zion.")
    desenhar_janela_central(TELA, LARGURA * 0.8, ALTURA * 0.6, (10,25,10), VERDE_MATRIX, "DIRETRIZES DO SISTEMA", regras, fonte_subtitulo, fonte)
    btn_w, btn_h = 380, 60
    btn_x = LARGURA // 2 - btn_w // 2
    btn_y = ALTURA - 90
    desenhar_botao(TELA, "Carregar Simulador", btn_x, btn_y, btn_w, btn_h, (10,40,10), (20,80,20), fonte_botao)
    rects_botoes_regras["iniciar"] = pygame.Rect(btn_x, btn_y, btn_w, btn_h)

def desenhar_tabuleiro():
    for idx, (x, y) in enumerate(jogo.CASAS):
        pygame.draw.rect(TELA, (0, 30, 0), (x, y, jogo.CASA_TAM, jogo.CASA_TAM), border_radius=4)
        pygame.draw.rect(TELA, (0, 80, 0), (x, y, jogo.CASA_TAM, jogo.CASA_TAM), 2, border_radius=4)
        if idx == 0: desenhar_texto(TELA, "Início", x + jogo.CASA_TAM//2, y + jogo.CASA_TAM//2, VERDE_MATRIX, True, fonte)
        elif idx == jogo.NUM_CASAS - 1: desenhar_texto(TELA, "Saída", x + jogo.CASA_TAM//2, y + jogo.CASA_TAM//2, VERDE_MATRIX, True, fonte)

def desenhar_linhas_tabuleiro():
    COR_LINHA = (0, 100, 0)
    for i in range(len(jogo.CASAS) - 1):
        x1, y1 = jogo.CASAS[i]
        x2, y2 = jogo.CASAS[i+1]
        centro1 = (x1 + jogo.CASA_TAM // 2, y1 + jogo.CASA_TAM // 2)
        centro2 = (x2 + jogo.CASA_TAM // 2, y2 + jogo.CASA_TAM // 2)
        pygame.draw.line(TELA, COR_LINHA, centro1, centro2, width=4)

def desenhar_hud():
    y0 = 15
    for i, p in enumerate(jogo.peoes):
        cor = AMARELO if i == jogo.jogador_atual else VERDE_MATRIX
        texto_status = f"{p['nome']} - Célula: {p['pos']+1}"
        if p.get("buff_ativo"):
            texto_status += " [MODO ESCOLHIDO]"
        desenhar_texto(TELA, texto_status, 25, y0 + i*25, cor, False, fonte_mono)
    jogador_da_vez = jogo.peoes[jogo.jogador_atual]
    desenhar_texto(TELA, f"Vez de: {jogador_da_vez['nome']}", LARGURA - 250, 15, AMARELO, True, fonte_mono)
    if "dado" in jogador_da_vez and jogador_da_vez['dado'] > 0 and estado_anim_dado == "nenhum":
        desenhar_texto(TELA, f"Dado: {jogador_da_vez['dado']}", LARGURA - 250, 40, BRANCO, True, fonte_mono)

def desenhar_jogo(clock):
    global frame_atual, timer_frame, rects_botoes_jogo
    rects_botoes_jogo = {} 
    TELA.fill(PRETO_MATRIX)
    if rain_effect: rain_effect.update_and_draw(TELA)
    desenhar_tabuleiro()
    desenhar_linhas_tabuleiro()
    
    timer_frame += clock.get_time()
    if timer_frame > TEMPO_FRAME:
        timer_frame = 0; frame_atual = (frame_atual + 1) % 2
        
    for i, p in enumerate(jogo.peoes):
        char_id = p.get("personagem_id")
        idx = min(p["pos"], len(jogo.CASAS)-1)
        x, y = jogo.CASAS[idx]
        cor_nome = BRANCO
        if p.get("buff_ativo"): cor_nome = (0, 255, 0)
        
        if char_id in peao_sprites:
            spritesheet = peao_sprites[char_id]
            frame_width = spritesheet.get_width() // 2
            frame_rect = pygame.Rect(frame_width * frame_atual, 0, frame_width, spritesheet.get_height())
            peao_img = spritesheet.subsurface(frame_rect)
            peao_img_redimensionada = pygame.transform.scale(peao_img, (55, 55))
            peao_rect = peao_img_redimensionada.get_rect(center=(x + jogo.CASA_TAM//2, y + jogo.CASA_TAM//2))
            TELA.blit(peao_img_redimensionada, peao_rect)
            if i == jogo.jogador_atual:
                desenhar_texto(TELA, p['nome'], peao_rect.centerx, peao_rect.top - 8, cor_nome, True, fonte_peao_nome)
        else:
            offset = (i - (num_jogadores-1)/2) * 12
            circ_x = x + jogo.CASA_TAM//2 + offset
            circ_y = y + jogo.CASA_TAM//2
            pygame.draw.circle(TELA, p["cor"], (circ_x, circ_y), 15)
            if i == jogo.jogador_atual:
                desenhar_texto(TELA, p['nome'], circ_x, circ_y - 22, cor_nome, True, fonte_peao_nome)

    desenhar_hud()
    
    jogador = jogo.peoes[jogo.jogador_atual]

    if jogo.mensagem_carta:
        w, h = LARGURA * 0.75, 300
        cx, cy = LARGURA // 2, ALTURA // 2
        ret_fundo = pygame.Rect(cx - w // 2, cy - h // 2, w, h)
        pygame.draw.rect(TELA, (10, 25, 10), ret_fundo, border_radius=8)
        pygame.draw.rect(TELA, VERDE_MATRIX, ret_fundo, 2, border_radius=8)
        desenhar_texto(TELA, ">>> TRANSMISSÃO EXECUTADA <<<", cx, ret_fundo.top + 20, VERDE_MATRIX, True, fonte_subtitulo)
        y_pos_sprite = ret_fundo.top + 65
        if jogo.personagem_carta and jogo.personagem_carta in personagem_sprites:
            sprite = personagem_sprites[jogo.personagem_carta]
            sprite_rect = sprite.get_rect(center=(cx, y_pos_sprite + sprite.get_height()//2 - 15))
            TELA.blit(sprite, sprite_rect); y_pos_texto = sprite_rect.bottom + 5
        else: y_pos_texto = y_pos_sprite
        padding = 30; ret_texto = pygame.Rect(ret_fundo.left + padding, y_pos_texto, w - padding*2, h - (y_pos_texto - ret_fundo.top) - 50)
        desenhar_texto_formatado(TELA, jogo.mensagem_carta, BRANCO, ret_texto, fonte)
            
    if estado_anim_dado == "rolando":
        if dice_roll_sprites: 
            frame = dice_roll_sprites[dado_frame_atual] 
            rect = frame.get_rect(center=(LARGURA // 2, ALTURA // 2))
            TELA.blit(frame, rect)
    elif estado_anim_dado == "resultado":
        if dado_resultado_sorteado in dice_result_sprites: 
            frame = dice_result_sprites[dado_resultado_sorteado]
            rect = frame.get_rect(center=(LARGURA // 2, ALTURA // 2))
            TELA.blit(frame, rect)

    if not animacao_em_andamento:
        btn_w, btn_h = 380, 60
        btn_x = LARGURA // 2 - btn_w // 2
        btn_y = ALTURA - 80
        if jogo.aguardando_carta:
            desenhar_botao(TELA, "CONTINUAR FLUXO", btn_x, btn_y, btn_w, btn_h, (10, 40, 10), (20, 80, 20), fonte_botao)
            rects_botoes_jogo["acao"] = pygame.Rect(btn_x, btn_y, btn_w, btn_h)
        elif estado_anim_dado == "nenhum":
            desenhar_botao(TELA, "ROLAR DADO DA MATRIX", btn_x, btn_y, btn_w, btn_h, (10, 40, 10), (20, 80, 20), fonte_botao)
            rects_botoes_jogo["acao"] = pygame.Rect(btn_x, btn_y, btn_w, btn_h)

def desenhar_falha_pilula():
    global rects_botoes_jogo
    rects_botoes_jogo = {}
    TELA.fill(PRETO_MATRIX)
    if rain_effect: rain_effect.update_and_draw(TELA)
    desenhar_tabuleiro()
    desenhar_hud()
    desenhar_janela_central(TELA, LARGURA * 0.75, 360, (25, 10, 10), VERMELHO, "CONEXÃO REJEITADA", jogo.MENSAGEM_FALHA_PILULA, fonte_subtitulo, fonte)
    
    btn_w, btn_h = 380, 60
    btn_x = LARGURA // 2 - btn_w // 2
    btn_y = ALTURA - 90
    desenhar_botao(TELA, "Reiniciar Loop Temporal", btn_x, btn_y, btn_w, btn_h, (40, 10, 10), (80, 20, 20), fonte_botao)
    rects_botoes_jogo["acao_falha"] = pygame.Rect(btn_x, btn_y, btn_w, btn_h)

def desenhar_fim():
    global rects_botoes_fim, epilogo_scroll_y, EPILOGO_LINES, fim_scroll_acabou
    TELA.fill(PRETO_MATRIX)
    if rain_effect: rain_effect.update_and_draw(TELA)
    rects_botoes_fim = {} 
    if not EPILOGO_LINES:
        epilogo_scroll_y = ALTURA + 40
        max_width = LARGURA * 0.85
        for pagina in jogo.PAGINAS_DO_EPILOGO:
            paragrafos = pagina.split('\n\n')
            for paragrafo in paragrafos:
                palavras = paragrafo.replace('\n', ' ').split(' ')
                linha_atual = ""
                for palavra in palavras:
                    linha_teste = linha_atual + palavra + " "
                    if fonte_prologo.size(linha_teste)[0] < max_width:
                        linha_atual = linha_teste
                    else:
                        EPILOGO_LINES.append(linha_atual)
                        linha_atual = palavra + " "
                EPILOGO_LINES.append(linha_atual)
                EPILOGO_LINES.append("")
    line_height = fonte_prologo.get_linesize()
    posicao_final_texto = epilogo_scroll_y + (len(EPILOGO_LINES) * line_height)
    if not fim_scroll_acabou:
        for i, line in enumerate(EPILOGO_LINES):
            y_pos = epilogo_scroll_y + (i * line_height)
            if y_pos < ALTURA and y_pos > -line_height:
                desenhar_texto(TELA, line, LARGURA // 2, y_pos, AMARELO, True, fonte_prologo)
        if posicao_final_texto < 0: 
            fim_scroll_acabou = True
    else:
        vencedor = None
        for p in jogo.peoes:
            if p["pos"] >= jogo.NUM_CASAS - 1: vencedor = p; break
        if not vencedor: vencedor = {"nome": "Ninguém"}
        desenhar_texto(TELA, f"Vitória de {vencedor['nome']}!", LARGURA//2, ALTURA//2 - 80, AMARELO, True, fonte_titulo)
        btn_w, btn_h = 280, 60
        btn_x = LARGURA // 2 - btn_w // 2
        desenhar_botao(TELA, "Jogar Novamente", btn_x, ALTURA//2 + 40, btn_w, btn_h, (10,40,10), (20,80,20), fonte_botao)
        rects_botoes_fim["reiniciar"] = pygame.Rect(btn_x, ALTURA//2 + 40, btn_w, btn_h)
        desenhar_botao(TELA, "Menu Principal", btn_x, ALTURA//2 + 40 + btn_h + 15, btn_w, btn_h, (40,10,10), (80,20,20), fonte_botao)
        rects_botoes_fim["menu"] = pygame.Rect(btn_x, ALTURA//2 + 40 + btn_h + 15, btn_w, btn_h)
    return posicao_final_texto 

def desenhar_pausa(clock):
    global rects_botoes_pausa
    rects_botoes_pausa = {} 
    overlay = pygame.Surface((LARGURA, ALTURA), pygame.SRCALPHA) 
    overlay.fill((0, 0, 0, 180)) 
    TELA.blit(overlay, (0, 0))
    desenhar_texto(TELA, "SISTEMA EM PAUSA", LARGURA // 2, ALTURA * 0.25, VERDE_MATRIX, True, fonte_titulo)
    btn_w, btn_h = 350, 60
    btn_x = LARGURA // 2 - btn_w // 2
    y_start = ALTURA * 0.42
    desenhar_botao(TELA, "Retornar ao Jogo", btn_x, y_start, btn_w, btn_h, (10, 40, 10), (20, 80, 20), fonte_botao)
    rects_botoes_pausa["continuar"] = pygame.Rect(btn_x, y_start, btn_w, btn_h)
    desenhar_botao(TELA, "Ajustes de Som", btn_x, y_start + btn_h + 15, btn_w, btn_h, (10, 10, 40), (20, 20, 80), fonte_botao)
    rects_botoes_pausa["opcoes"] = pygame.Rect(btn_x, y_start + btn_h + 15, btn_w, btn_h)
    desenhar_botao(TELA, "Terminar Partida", btn_x, y_start + 2 * (btn_h + 15), btn_w, btn_h, (40, 10, 10), (80, 20, 20), fonte_botao)
    rects_botoes_pausa["menu"] = pygame.Rect(btn_x, y_start + 2 * (btn_h + 15), btn_w, btn_h)

def desenhar_mostrar_buff(clock):
    global jogador_com_buff, rects_botoes_jogo
    if not jogador_com_buff: return 
    desenhar_jogo(clock)
    rects_botoes_jogo = {} 
    
    nome_jogador = jogador_com_buff['nome']
    
    texto = (f"Saudações, {nome_jogador}. Rompemos o firewall da Matrix.\n\n"
             "**MODO ESCOLHIDO ATIVADO:**\n"
             "Suas diretrizes agora dominam as probabilidades do código.\n"
             "Sua chance de decodificar transmissões Boas subiu para **70%**.\n"
             "Risco de invasões e Agentes Smith caiu para **30%**.\n\n"
             f"*Toque no botão abaixo para consolidar a alteração*")

    w, h = LARGURA * 0.75, 380 
    cx, cy = LARGURA // 2, ALTURA // 2
    ret_fundo = pygame.Rect(cx - w // 2, cy - h // 2, w, h)
    pygame.draw.rect(TELA, (10, 25, 10), ret_fundo, border_radius=8)
    pygame.draw.rect(TELA, VERDE_MATRIX, ret_fundo, 2, border_radius=8)
    desenhar_texto(TELA, ">>> BUFFER RECONFIGURADO <<<", cx, ret_fundo.top + 20, VERDE_MATRIX, True, fonte_subtitulo)
    
    y_pos_sprite = ret_fundo.top + 65
    if "neo" in personagem_sprites:
        sprite = personagem_sprites["neo"]
        sprite_rect = sprite.get_rect(center=(cx, y_pos_sprite + sprite.get_height()//2 - 15))
        TELA.blit(sprite, sprite_rect); y_pos_texto = sprite_rect.bottom + 5
    else: 
        y_pos_texto = y_pos_sprite
    
    padding = 30
    ret_texto = pygame.Rect(ret_fundo.left + padding, y_pos_texto, w - padding*2, h - (y_pos_texto - ret_fundo.top) - 50)
    desenhar_texto_formatado(TELA, texto, BRANCO, ret_texto, fonte)

    btn_w, btn_h = 380, 60
    btn_x = LARGURA // 2 - btn_w // 2
    btn_y = ALTURA - 80
    desenhar_botao(TELA, "INICIALIZAR FIRMWARE", btn_x, btn_y, btn_w, btn_h, (10, 40, 10), (20, 80, 20), fonte_botao)
    rects_botoes_jogo["acao"] = pygame.Rect(btn_x, btn_y, btn_w, btn_h)

# =====================================================================================
# FUNÇÃO PRINCIPAL OBRIGATÓRIA DA WEB (ASYNCIO RESTAURADO)
# =====================================================================================

async def main():
    global LARGURA, ALTURA, TELA, estado, nomes, foco_jogador, cursor_on, cursor_timer
    global num_jogadores, jogador_selecionando, personagens_escolhidos, estado_anterior_opcoes
    global jogador_com_buff, pilula_final_peao, prologo_scroll_y, PROLOGO_LINES
    global epilogo_scroll_y, EPILOGO_LINES, fim_scroll_acabou, animacao_em_andamento
    global peao_animando, passos_restantes, passos_direcao, o_que_fazer_depois_anim, animacao_replay
    global timer_animacao, frame_atual, timer_frame, rects_botoes_pilula, timer_cutscene_estatica
    global rects_botoes_menu, rects_botoes_opcoes, rects_botoes_qtd, rects_botoes_nome
    global rects_botoes_selecao, rects_botoes_pausa, rects_botoes_prologo, rects_botoes_regras
    global rects_botoes_fim, rects_botoes_jogo, rain_effect, clock, VOLUME_GERAL, VOLUME_MUSICA, VOLUME_EFEITOS
    global estado_anim_dado, timer_anim_dado
    global dado_frame_timer, dado_frame_atual, dado_resultado_sorteado

    def executar_acao_jogador():
        global estado, jogador_com_buff, estado_anim_dado, timer_anim_dado
        global dado_frame_timer, dado_frame_atual, animacao_em_andamento
        global peao_animando, passos_restantes, passos_direcao, o_que_fazer_depois_anim, animacao_replay
        
        if estado == MOSTRAR_BUFF:
            estado = JOGO; jogador_com_buff = None 
        elif estado == JOGO:
            jogador = jogo.peoes[jogo.jogador_atual]
            if not animacao_em_andamento and not jogo.aguardando_carta and estado_anim_dado == "nenhum":
                estado_anim_dado = "rolando"; timer_anim_dado = 0; dado_frame_timer = 0; dado_frame_atual = 0
                tocar_som(dice_roll_sound)
            elif jogo.aguardando_carta:
                efeitos = jogo.aplicar_carta(jogador, jogo.carta_atual)
                jogo.aguardando_carta = False; jogo.mensagem_carta = None; jogador['dado'] = 0 
                movimento = 0; destino_final = jogador["pos"]; passos_direcao = 1
                animacao_replay = efeitos.get("replay", False) 
                if "mov" in efeitos: movimento = efeitos["mov"] 
                elif "voltar_turno" in efeitos: movimento = jogador["pos_anterior"] - jogador["pos"] 
                elif "voltar_inicio_fileira" in efeitos: destino_final = (jogador["pos"] // 8) * 8; movimento = destino_final - jogador["pos"] 
                if movimento != 0:
                    destino_final = jogador["pos"] + movimento; destino_final = max(0, min(jogo.NUM_CASAS - 1, destino_final)); movimento = destino_final - jogador["pos"]
                    animacao_em_andamento = True; peao_animando = jogador; passos_restantes = abs(movimento); passos_direcao = 1 if movimento > 0 else -1; o_que_fazer_depois_anim = "AVANCAR_TURNO" 
                else:
                    jogo.avancar_turno(replay=animacao_replay)

    loading_rain_effect = LoadingRain(LARGURA, ALTURA, fonte_loading_rain)
    asset_loader = carregar_assets() 
    carregando = True
    progresso_atual = 0
    total_assets = 1 

    TELA.fill(PRETO_MATRIX)
    desenhar_tela_loading(0, 1, loading_rain_effect)

    while carregando:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT: pygame.quit(); sys.exit()

        try:
            resultado = next(asset_loader)
            progresso_atual, total_assets = resultado
        except StopIteration:
            carregando = False; progresso_atual = total_assets
        
        desenhar_tela_loading(progresso_atual, total_assets, loading_rain_effect)
        await asyncio.sleep(0)  

    jogo.criar_tabuleiro(LARGURA, ALTURA) 
    jogo.criar_jogadores(num_jogadores=2) 
    rain_effect = MatrixRain(LARGURA, ALTURA, fonte_mono) 

    rodando = True
    clock = pygame.time.Clock()
    posicao_final_texto_prologo = 0 
    posicao_final_texto_epilogo = 0 

    while rodando:
        delta_time = clock.tick(60)
        eventos = pygame.event.get()
        mouse_pos = pygame.mouse.get_pos() 

        for evento in eventos:
            if evento.type == pygame.QUIT: rodando = False

            if evento.type == pygame.MOUSEBUTTONUP or evento.type == pygame.MOUSEBUTTONDOWN:
                if estado == SPLASH_SCREEN:
                    estado = MENU 
                    tocar_musica() 
                
                elif evento.type == pygame.MOUSEBUTTONUP: 
                    if estado == MENU:
                        if "iniciar" in rects_botoes_menu and rects_botoes_menu["iniciar"].collidepoint(mouse_pos):
                            tocar_som(click_sound)
                            estado = PROLOGO; PROLOGO_LINES = []; prologo_scroll_y = ALTURA + 40 
                        elif "opcoes" in rects_botoes_menu and rects_botoes_menu["opcoes"].collidepoint(mouse_pos):
                            tocar_som(click_sound)
                            estado = OPCOES; estado_anterior_opcoes = MENU 
                        elif "sair" in rects_botoes_menu and rects_botoes_menu["sair"].collidepoint(mouse_pos):
                            pygame.quit(); sys.exit()
                    
                    elif estado == PROLOGO:
                        if "pular" in rects_botoes_prologo and rects_botoes_prologo["pular"].collidepoint(mouse_pos):
                            tocar_som(click_sound); PROLOGO_LINES = []; estado = QTD_JOGADORES
                    
                    elif estado == REGRAS:
                        if "iniciar" in rects_botoes_regras and rects_botoes_regras["iniciar"].collidepoint(mouse_pos):
                            tocar_som(click_sound); parar_musica(); estado = CUTSCENE; timer_cutscene_estatica = 0 

                    elif estado == OPCOES:
                        if "geral-" in rects_botoes_opcoes and rects_botoes_opcoes["geral-"].collidepoint(mouse_pos):
                            tocar_som(click_sound); VOLUME_GERAL = max(0.0, round(VOLUME_GERAL - 0.1, 1))
                        elif "geral+" in rects_botoes_opcoes and rects_botoes_opcoes["geral+"].collidepoint(mouse_pos):
                            tocar_som(click_sound); VOLUME_GERAL = min(1.0, round(VOLUME_GERAL + 0.1, 1))
                        elif "musica-" in rects_botoes_opcoes and rects_botoes_opcoes["musica-"].collidepoint(mouse_pos):
                            tocar_som(click_sound); VOLUME_MUSICA = max(0.0, round(VOLUME_MUSICA - 0.1, 1))
                        elif "musica+" in rects_botoes_opcoes and rects_botoes_opcoes["musica+"].collidepoint(mouse_pos):
                            tocar_som(click_sound); VOLUME_MUSICA = min(1.0, round(VOLUME_MUSICA + 0.1, 1))
                        elif "efeitos-" in rects_botoes_opcoes and rects_botoes_opcoes["efeitos-"].collidepoint(mouse_pos):
                            tocar_som(click_sound); VOLUME_EFEITOS = max(0.0, round(VOLUME_EFEITOS - 0.1, 1))
                        elif "efeitos+" in rects_botoes_opcoes and rects_botoes_opcoes["efeitos+"].collidepoint(mouse_pos):
                            tocar_som(click_sound); VOLUME_EFEITOS = min(1.0, round(VOLUME_EFEITOS + 0.1, 1))
                        elif "voltar" in rects_botoes_opcoes and rects_botoes_opcoes["voltar"].collidepoint(mouse_pos):
                            tocar_som(click_sound); estado = PAUSA if estado_anterior_opcoes == PAUSA else MENU; estado_anterior_opcoes = None 
                        
                        pygame.mixer.music.set_volume(VOLUME_GERAL * VOLUME_MUSICA)
                            
                    elif estado == QTD_JOGADORES:
                        for i in range(2, 5):
                            if i in rects_botoes_qtd and rects_botoes_qtd[i].collidepoint(mouse_pos):
                                tocar_som(click_sound); num_jogadores = i; jogo.criar_jogadores(num_jogadores); estado = NOME; break
                    elif estado == NOME:
                        if "confirmar" in rects_botoes_nome and rects_botoes_nome["confirmar"].collidepoint(mouse_pos):
                            tocar_som(click_sound)
                            for i in range(num_jogadores):
                                if nomes[i].strip(): jogo.peoes[i]["nome"] = nomes[i].strip()
                            estado = SELECAO_PERSONAGEM
                    elif estado == SELECAO_PERSONAGEM:
                        for i in range(1, len(selecao_sprites) + 1):
                            if i in rects_botoes_selecao and rects_botoes_selecao[i].collidepoint(mouse_pos) and i not in personagens_escolhidos:
                                tocar_som(click_sound); jogo.peoes[jogador_selecionando]["personagem_id"] = i; personagens_escolhidos.append(i); jogador_selecionando += 1
                                if jogador_selecionando >= num_jogadores: jogador_selecionando = 0; personagens_escolhidos = []; estado = REGRAS 
                                break
                    
                    elif estado == CUTSCENE:
                        estado = JOGO; timer_cutscene_estatica = 0
                        tocar_musica()

                    elif estado == PILULA_FINAL:
                        if "azul" in rects_botoes_pilula and rects_botoes_pilula["azul"].collidepoint(mouse_pos):
                             tocar_som(click_sound); resultado = jogo.aplicar_escolha_pilula_final(0)
                             if resultado == "sair": pagina_epilogo_atual = 0; estado = FIM; EPILOGO_LINES = []; fim_scroll_acabou = False 
                             else: estado = PILULA_FALHA; tocar_som(falha_sound) 
                        elif "vermelha" in rects_botoes_pilula and rects_botoes_pilula["vermelha"].collidepoint(mouse_pos):
                             tocar_som(click_sound); resultado = jogo.aplicar_escolha_pilula_final(1)
                             if resultado == "sair": pagina_epilogo_atual = 0; estado = FIM; EPILOGO_LINES = []; fim_scroll_acabou = False 
                             else: estado = PILULA_FALHA; tocar_som(falha_sound) 
                    
                    elif estado == PILULA_FALHA:
                        if "acao_falha" in rects_botoes_jogo and rects_botoes_jogo["acao_falha"].collidepoint(mouse_pos):
                            tocar_som(click_sound); jogador_com_buff = pilula_final_peao 
                            if not jogador_com_buff["buff_ativo"]: jogador_com_buff["buff_ativo"] = True
                            movimento = 0 - jogador_com_buff["pos"] 
                            animacao_em_andamento = True; peao_animando = jogador_com_buff; passos_restantes = abs(movimento); passos_direcao = -1; o_que_fazer_depois_anim = "MOSTRAR_BUFF"; estado = JOGO
                    
                    elif estado in [JOGO, MOSTRAR_BUFF]:
                        if "acao" in rects_botoes_jogo and rects_botoes_jogo["acao"].collidepoint(mouse_pos):
                            tocar_som(click_sound); executar_acao_jogador()

                    elif estado == FIM:
                        if fim_scroll_acabou: 
                            if "reiniciar" in rects_botoes_fim and rects_botoes_fim["reiniciar"].collidepoint(mouse_pos):
                                tocar_som(click_sound); jogo.resetar_partida(); estado = JOGO; EPILOGO_LINES = []; fim_scroll_acabou = False
                            elif "menu" in rects_botoes_fim and rects_botoes_fim["menu"].collidepoint(mouse_pos):
                                tocar_som(click_sound); jogo.resetar_partida(); estado = MENU; EPILOGO_LINES = []; fim_scroll_acabou = False
                    
                    elif estado == PAUSA:
                        if "continuar" in rects_botoes_pausa and rects_botoes_pausa["continuar"].collidepoint(mouse_pos):
                            tocar_som(click_sound); estado = JOGO; despausar_musica() 
                        elif "opcoes" in rects_botoes_pausa and rects_botoes_pausa["opcoes"].collidepoint(mouse_pos):
                            tocar_som(click_sound); estado = OPCOES; estado_anterior_opcoes = PAUSA 
                        elif "menu" in rects_botoes_pausa and rects_botoes_pausa["menu"].collidepoint(mouse_pos):
                            tocar_som(click_sound); estado = MENU; despausar_musica(); jogo.resetar_partida(); estado_anterior_opcoes = None 

            if evento.type == pygame.KEYDOWN:
                if estado == SPLASH_SCREEN: 
                    estado = MENU 
                    tocar_musica()
                elif estado == PROLOGO: PROLOGO_LINES = []; estado = QTD_JOGADORES 
                elif estado == CUTSCENE:
                    estado = JOGO 
                    tocar_musica()
                elif estado == REGRAS: parar_musica(); estado = CUTSCENE; timer_cutscene_estatica = 0
                elif estado == NOME:
                    if evento.key == pygame.K_TAB: foco_jogador = (foco_jogador + 1) % num_jogadores
                    elif evento.key == pygame.K_BACKSPACE: nomes[foco_jogador] = nomes[foco_jogador][:-1]
                    elif evento.key == pygame.K_RETURN or evento.key == pygame.K_KP_ENTER:
                         for i in range(num_jogadores):
                             if nomes[i].strip(): jogo.peoes[i]["nome"] = nomes[i].strip()
                         estado = SELECAO_PERSONAGEM
                    else:
                        ch = evento.unicode
                        if ch and len(ch) == 1 and ch.isprintable() and len(nomes[foco_jogador]) < 18: nomes[foco_jogador] += ch
                elif estado == PILULA_FALHA:
                    jogador_com_buff = pilula_final_peao 
                    if not jogador_com_buff["buff_ativo"]: jogador_com_buff["buff_ativo"] = True
                    movimento = 0 - jogador_com_buff["pos"] 
                    animacao_em_andamento = True; peao_animando = jogador_com_buff; passos_restantes = abs(movimento); passos_direcao = -1; o_que_fazer_depois_anim = "MOSTRAR_BUFF"; estado = JOGO 
                elif estado == MOSTRAR_BUFF:
                    if jogador_com_buff and evento.key == jogador_com_buff["tecla"]: executar_acao_jogador()
                elif estado == FIM:
                    if not fim_scroll_acabou: fim_scroll_acabou = True 
                elif estado == JOGO:
                    if evento.key == pygame.K_ESCAPE: estado = PAUSA; pausar_musica() 
                    elif not jogador_com_buff:
                        jogador = jogo.peoes[jogo.jogador_atual]
                        if evento.key == jogador["tecla"]: executar_acao_jogador()
                elif estado == PAUSA:
                    if evento.key == pygame.K_ESCAPE: estado = JOGO; despausar_musica(); estado_anterior_opcoes = None 

        if estado != PAUSA:
            
            if estado == PROLOGO:
                prologo_scroll_y -= PROLOGO_SCROLL_SPEED * (delta_time / 16.6) 
                if posicao_final_texto_prologo < 0: PROLOGO_LINES = []; estado = QTD_JOGADORES 

            if estado == CUTSCENE:
                timer_cutscene_estatica += delta_time
                if timer_cutscene_estatica > DURACAO_CUTSCENE_WEB:
                    estado = JOGO; timer_cutscene_estatica = 0
                    tocar_musica()
            
            if estado == FIM and not fim_scroll_acabou:
                epilogo_scroll_y -= EPILOGO_SCROLL_SPEED * (delta_time / 16.6)
                if posicao_final_texto_epilogo < -200: fim_scroll_acabou = True

            if estado_anim_dado == "rolando":
                timer_anim_dado += delta_time; dado_frame_timer += delta_time
                if dado_frame_timer > TEMPO_FRAME_DADO and dice_roll_sprites:
                    dado_frame_timer = 0; dado_frame_atual = random.randint(0, len(dice_roll_sprites) - 1)
                if timer_anim_dado > DURACAO_ANIM_DADO:
                    estado_anim_dado = "resultado"; timer_anim_dado = 0 
                    jogador = jogo.peoes[jogo.jogador_atual]
                    dado_resultado_sorteado = jogo.jogar_vez(jogador)
                    jogador['dado'] = dado_resultado_sorteado 
            elif estado_anim_dado == "resultado":
                timer_anim_dado += delta_time
                if timer_anim_dado > DURACAO_MOSTRAR_DADO:
                    estado_anim_dado = "nenhum"; timer_anim_dado = 0
                    animacao_em_andamento = True; peao_animando = jogo.peoes[jogo.jogador_atual]; passos_restantes = dado_resultado_sorteado; passos_direcao = 1; o_que_fazer_depois_anim = "PUXAR_CARTA"; dado_resultado_sorteado = 0 
            
            if animacao_em_andamento:
                timer_animacao += delta_time 
                if timer_animacao > TEMPO_PASSO: 
                    timer_animacao = 0
                    if passos_restantes > 0:
                        peao_animando["pos"] += passos_direcao; passos_restantes -= 1
                        tocar_som(move_sound)
                    if passos_restantes == 0:
                        animacao_em_andamento = False
                        peao_animando["pos"] = max(0, min(jogo.NUM_CASAS - 1, peao_animando["pos"]))
                        if o_que_fazer_depois_anim == "PUXAR_CARTA":
                            if jogo.is_escolha_pilula_final(peao_animando["pos"]):
                                pilula_final_peao = peao_animando; estado = PILULA_FINAL; jogo.sortear_pilulas_final()
                            else:
                                jogo.puxar_carta(peao_animando) 
                        elif o_que_fazer_depois_anim == "AVANCAR_TURNO":
                            jogo.avancar_turno(replay=animacao_replay); animacao_replay = False 
                        elif o_que_fazer_depois_anim == "MOSTRAR_BUFF":
                            estado = MOSTRAR_BUFF
                        o_que_fazer_depois_anim = None 

        TELA.fill(PRETO_MATRIX)
        if estado == SPLASH_SCREEN: desenhar_splash_screen()
        elif estado == MENU: desenhar_menu()
        elif estado == OPCOES: desenhar_opcoes()
        elif estado == QTD_JOGADORES: desenhar_qtd_jogadores()
        elif estado == NOME: desenhar_nome()
        elif estado == SELECAO_PERSONAGEM: desenhar_selecao_personagem()
        elif estado == PROLOGO: posicao_final_texto_prologo = desenhar_prologo() 
        elif estado == CUTSCENE: desenhar_cutscene() 
        elif estado == REGRAS: desenhar_regras()
        elif estado == JOGO: desenhar_jogo(clock)
        elif estado == PILULA_FALHA: desenhar_falha_pilula()
        elif estado == MOSTRAR_BUFF: desenhar_mostrar_buff(clock) 
        elif estado == PILULA_FINAL:
            rects_botoes_pilula = {}
            if rain_effect: rain_effect.update_and_draw(TELA)
            desenhar_tabuleiro(); desenhar_linhas_tabuleiro()
            for i, p in enumerate(jogo.peoes): 
                char_id = p.get("personagem_id"); idx = min(p["pos"], len(jogo.CASAS)-1); x, y = jogo.CASAS[idx]
                if char_id in peao_sprites:
                    spritesheet = peao_sprites[char_id]; frame_width = spritesheet.get_width() // 2; frame_rect = pygame.Rect(frame_width * frame_atual, 0, frame_width, spritesheet.get_height())
                    peao_img = spritesheet.subsurface(frame_rect); peao_img_redimensionada = pygame.transform.scale(peao_img, (55, 55)); peao_rect = peao_img_redimensionada.get_rect(center=(x + jogo.CASA_TAM//2, y + jogo.CASA_TAM//2))
                    TELA.blit(peao_img_redimensionada, peao_rect)
                else:
                    offset = (i - (num_jogadores-1)/2) * 12; circ_x = x + jogo.CASA_TAM//2 + offset; circ_y = y + jogo.CASA_TAM//2
                    pygame.draw.circle(TELA, p["cor"], (circ_x, circ_y), 15)
            desenhar_hud()
            texto_morpheus = ("A voz do Operador soa distorcida...\n\n'É agora! Encontramos uma brecha, mas ela não vai durar.\nUma pílula te levará para a saída... a outra irá te prender ao código-fonte, reiniciando seu loop.\n\nConfie no seu instinto. Acredite.'")
            desenhar_janela_central(TELA, LARGURA * 0.85, 450, (10,25,10), VERDE_MATRIX, "A ESCOLHA FINAL", texto_morpheus, fonte_subtitulo, fonte)
            btn_w, btn_h = 350, 80
            y_btn = ALTURA//2 + 100
            desenhar_botao(TELA, "Pílula Azul", LARGURA//2 - btn_w - 20, y_btn, btn_w, btn_h, (10,10,60), (20,20,120), fonte_botao)
            rects_botoes_pilula["azul"] = pygame.Rect(LARGURA//2 - btn_w - 20, y_btn, btn_w, btn_h)
            desenhar_botao(TELA, "Pílula Vermelha", LARGURA//2 + 20, y_btn, btn_w, btn_h, (60,10,10), (120,20,20), fonte_botao)
            rects_botoes_pilula["vermelha"] = pygame.Rect(LARGURA//2 + 20, y_btn, btn_w, btn_h)
        
        elif estado == FIM: 
            posicao_final_texto_epilogo = desenhar_fim() 
        
        elif estado == PAUSA:
            desenhar_jogo(clock); desenhar_pausa(clock) 

        pygame.display.flip()
        await asyncio.sleep(0)  

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())